#-----------------------------------------------------------------
# pycparser: portability.py
#
# Portability code for working with different versions of Python
#
# Copyright (C) 2008-2010, Eli Bendersky
# License: LGPL
#----------------------
import sys


def printme(s):
    sys.stdout.write(str(s))




     