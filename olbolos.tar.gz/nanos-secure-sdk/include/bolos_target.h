#ifndef ST31
#define ST31
#endif // ST31
#define TARGET_ID 0x31100004
#define TARGET_NANOS
