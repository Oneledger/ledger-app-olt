#ifndef BOLOS_VERSION
#define BOLOS_VERSION "1.6.1"
#endif
