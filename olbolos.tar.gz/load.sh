#!/bin/bash

sudo apt-get update -y

sudo apt-get install -y libudev-dev libusb-1.0-0-dev python3-dev virtualenv git make gcc 

wget -q -O - https://raw.githubusercontent.com/LedgerHQ/udev-rules/master/add_udev_rules.sh | sudo bash

export BOLOS_SDK=~/bolos/nanos-secure-sdk
export BOLOS_ENV=~/bolos

virtualenv -p python3 ledger
source ledger/bin/activate
pip install ledgerblue

make load

deactivate
